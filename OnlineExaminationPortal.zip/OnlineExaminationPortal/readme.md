ReadMe file for my Online Exams Portal project.
