<?php
   require "newexaminer.php";
   header("location:addexaminer.php");
?>